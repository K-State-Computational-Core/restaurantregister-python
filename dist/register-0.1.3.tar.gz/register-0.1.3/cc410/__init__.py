"""Meta package for all cc410 project packages.

Author: Russell Feldhausen russfeld@ksu.edu
Version: 0.1
"""
