"""Meta package for all project test packages.

Author: Russell Feldhausen russfeld@ksu.edu
Version: 0.1
"""
