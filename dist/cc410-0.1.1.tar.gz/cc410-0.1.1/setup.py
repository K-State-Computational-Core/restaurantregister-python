"""Setup file for packaging.

See https://packaging.python.org/tutorials/packaging-projects/

Author: Russell Feldhausen
Version: 0.1
"""

import setuptools

setuptools.setup()
