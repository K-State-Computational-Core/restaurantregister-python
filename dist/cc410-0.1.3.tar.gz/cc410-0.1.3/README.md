# CC 410 Restaurant Register

This library is intended for use in CC 410 course at Kansas State University

[Documentation](https://k-state-computational-core.github.io/restaurantregister-python/)

For more information, see the [CC program website](http://www.cs.ksu.edu/core/)

