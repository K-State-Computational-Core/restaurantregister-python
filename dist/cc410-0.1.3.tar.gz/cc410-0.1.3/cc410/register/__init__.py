"""Meta package for cc410.register.

Author: Russell Feldhausen russfeld@ksu.edu
Version: 0.1
"""
