"""Meta package for all cc410.register test packages.

Author: Russell Feldhausen russfeld@ksu.edu
Version: 0.1
"""
